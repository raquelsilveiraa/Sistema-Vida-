const express = require('express');
const router = express.Router();
const Notification = require('../models/notification');

// Buscar todas as notificações
router.get('/', (req, res) => {
    Notification.findAll((err, notifications) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(notifications);
    });
});

// Criar uma nova notificação
router.post('/', (req, res) => {
    const newNotification = req.body;
    Notification.create(newNotification, (err, notification) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json(notification);
    });
});

module.exports = router;
