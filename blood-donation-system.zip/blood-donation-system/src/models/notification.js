const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../../data.json');

class Notification {
    static findAll(callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            callback(null, jsonData.notifications);
        });
    }

    static create(newNotification, callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            newNotification.id = jsonData.notifications.length + 1;
            jsonData.notifications.push(newNotification);
            fs.writeFile(dataPath, JSON.stringify(jsonData, null, 2), err => {
                if (err) callback(err, null);
                callback(null, newNotification);
            });
        });
    }
}

module.exports = Notification;
