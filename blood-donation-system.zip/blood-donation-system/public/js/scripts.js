// Scripts para carregamento dinâmico
document.addEventListener("DOMContentLoaded", () => {
    const notificationsContainer = document.getElementById("notifications-container");
    
    if (notificationsContainer) {
        fetch('/notifications')
            .then(response => response.json())
            .then(notifications => {
                notifications.forEach(notification => {
                    const notificationDiv = document.createElement("div");
                    notificationDiv.innerText = `Tipo Sanguíneo: ${notification.blood_type}, Mensagem: ${notification.message}`;
                    notificationsContainer.appendChild(notificationDiv);
                });
            });
    }
});
