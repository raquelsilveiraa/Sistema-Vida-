const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../../data.json');

class Institution {
    static findAll(callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            callback(null, jsonData.institutions);
        });
    }

    static findById(id, callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            const institution = jsonData.institutions.find(inst => inst.id === id);
            callback(null, institution);
        });
    }

    static create(newInstitution, callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            newInstitution.id = jsonData.institutions.length + 1;
            jsonData.institutions.push(newInstitution);
            fs.writeFile(dataPath, JSON.stringify(jsonData, null, 2), err => {
                if (err) callback(err, null);
                callback(null, newInstitution);
            });
        });
    }

    static delete(id, callback) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) callback(err, null);
            const jsonData = JSON.parse(data);
            jsonData.institutions = jsonData.institutions.filter(inst => inst.id !== id);
            fs.writeFile(dataPath, JSON.stringify(jsonData, null, 2), err => {
                if (err) callback(err, null);
                callback(null, { message: 'Institution deleted' });
            });
        });
    }
}

module.exports = Institution;
