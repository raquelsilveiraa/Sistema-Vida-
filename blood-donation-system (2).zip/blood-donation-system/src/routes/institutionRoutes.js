const express = require('express');
const router = express.Router();
const Institution = require('../models/institution');

// Buscar todas as instituições
router.get('/', (req, res) => {
    Institution.findAll((err, institutions) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(institutions);
    });
});

// Criar uma nova instituição
router.post('/', (req, res) => {
    const newInstitution = req.body;
    Institution.create(newInstitution, (err, institution) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json(institution);
    });
});

module.exports = router;
