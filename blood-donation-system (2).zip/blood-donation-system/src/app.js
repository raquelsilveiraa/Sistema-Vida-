const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Rota para página inicial (login)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/login.html'));
});

app.post('/login', (req, res) => {
    const { login, password } = req.body;

    // Simulação de autenticação
    if (login === 'admin' && password === '12345') {
        res.redirect('/home'); // Redireciona para a página Home
    } else {
        res.status(401).send('Credenciais inválidas. <a href="/">Tentar novamente</a>');
    }
});

// Rota para página Home
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/home.html'));
});

app.get('/logout', (req, res) => {
    // Redireciona o usuário para a página de login
    res.redirect('/');
});


// Rota para página de Perfil do Usuário
app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/profile.html'));
});

// Rota para página de Instituições de Doação
app.get('/institutions', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/institutions.html'));
});

//Rota para página ver detalhes
app.get('/institutions/:id', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/institution-details.html'));
});

// Rota para agendamento
app.get('/schedule', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/schedule.html'));
});

app.post('/schedule-confirm', (req, res) => {
    const { institution, date, time } = req.body;

    // Validar se os dados foram preenchidos corretamente
    if (!institution || !date || !time) {
        return res.status(400).send('Erro: Todos os campos são obrigatórios!');
    }

    // Exibir informações de confirmação no console
    console.log(`Agendamento confirmado: Instituição ${institution}, Data ${date}, Horário ${time}`);

    // Redirecionar ou exibir uma mensagem
    res.send(`
        <h1>Agendamento Confirmado</h1>
        <p>Instituição: ${institution}</p>
        <p>Data: ${date}</p>
        <p>Horário: ${time}</p>
        <a href="/home">Voltar para Home</a>
    `);
});

app.get('/institutions/:id', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/institution-details.html'));
});

// Rota para a página de notificações
app.get('/notifications', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/notifications.html'));
});

// Inicializar servidor
const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT} Coloque no navegador http://localhost:3000/ com login:admin e senha:12345`));
